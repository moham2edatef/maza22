import 'package:flutter/material.dart';

class AppColor {
  static const primary = Colors.blue;
}
